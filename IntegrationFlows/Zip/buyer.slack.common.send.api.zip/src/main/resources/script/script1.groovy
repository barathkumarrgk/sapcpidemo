import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.securestore.exception.SecureStoreException

def Message processData(Message message) {
    
    def apikey_alias = message.getProperty("BotToken")
    def textvalue = message.getBody(java.lang.String)
    
    //Get Bot Token from Key Store Secure Parameter
    def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    try{
        def secureParameter = secureStorageService.getUserCredential(apikey_alias)
        def apikey = secureParameter.getPassword().toString()
        message.setHeader("Authorization","Bearer "+apikey)
    } catch(Exception e){
        throw new SecureStoreException("Secure Parameter not available")
    }
    
    //Function for URL encoding
    
        String.metaClass.encodeURL = 
        {
       java.net.URLEncoder.encode(delegate,"ASCII")
        }
    
    //url encoding to allow special characters in parameters    
    def encodedUrl = textvalue.encodeURL()
    
    message.setProperty("text", encodedUrl)
    
    def body = "";
    message.setBody(body) 
    return message;

}